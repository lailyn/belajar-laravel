<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SiswaController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\HitungController;
Route::get('/hitung', [HitungController::class, 'index']);
Route::get('/hitung/data', [HitungController::class, 'hitung']);



// arahkan url /siswa ke function index di  SiswaC ontroller
// Route::get('/siswa','SiswaController@index')
Route::get('/', [AuthController::class, 'login'])->name('login');
Route::get('/login', [AuthController::class, 'login'])->name('login');
Route::get('/logout', [AuthController::class, 'logout']);
Route::post('/postLogin', [AuthController::class, 'postLogin']);

Route::group(['middleware'=>'auth'],function(){
    Route::get('/dashboard', [DashboardController::class, 'index'])->middleware('auth');
    Route::get('siswa', [SiswaController::class, 'index']);
    Route::post('siswa/create', [SiswaController::class, 'create']);
    Route::get('siswa/add', [SiswaController::class, 'add']);
    Route::get('siswa/{id}/edit', [SiswaController::class, 'edit']);
    Route::get('siswa/{id}/profil', [SiswaController::class, 'profil']);
    Route::post('siswa/{id}/update', [SiswaController::class, 'update']);
    Route::get('siswa/{id}/delete', [SiswaController::class, 'delete']);
});
