<?php $__env->startSection('content'); ?>
    <h1>Profil Siswa
    <a href="/siswa" class="btn btn-primary float-right btn-sm">
      Kembali
    </a>
    </h1>    
    <div class="media">
      <?php if(!is_null($siswa->avatar)): ?>
      <img class="mr-3" src="<?php echo e(asset('images/'.$siswa->avatar)); ?>">      
      <?php else: ?>
      <img width="200px" class="mr-3" src="<?php echo e(asset('images/default.jpg')); ?>">      
      <?php endif; ?>  
      
      <div class="media-body">
        Nama Depan : <?php echo e($siswa->nama_depan); ?><br>
        Nama Belakang : <?php echo e($siswa->nama_belakang); ?><br>
        Alamat : <?php echo e($siswa->alamat); ?><br>
        Agama : <?php echo e($siswa->agama); ?><br>
        Jenis Kelamin : <?php echo e($siswa->jenis_kelamin); ?><br>
      </div>
      <a href='/siswa/<?php echo e($siswa->id); ?>/edit' class="btn btn-sm btn-warning">edit</a>
    </div>      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/belajar/laravel/belajar_laravel/resources/views/siswa/profil.blade.php ENDPATH**/ ?>