<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Data Siswa<a href="/siswa/add" class="btn btn-primary btn-sm">Add</a></h1> 
      <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Dashboard</li>
      </ol>      
    <?php if(session('sukses')): ?>
    <div class="alert alert-success" role="alert"><?php echo e(session('sukses')); ?></div>
    <?php endif; ?>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>Nama Depan</th>
              <th>Nama Belakang</th>
              <th>JK</th>
              <th>Agama</th>
              <th>Alamat</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><a href='/siswa/<?php echo e($amb->id); ?>/profil'><?php echo e($amb->nama_depan); ?></a></td>
            <td><a href='/siswa/<?php echo e($amb->id); ?>/profil'><?php echo e($amb->nama_belakang); ?></a></td>
            <td><?php echo e($amb->jenis_kelamin); ?></td>
            <td><?php echo e($amb->agama); ?></td>
            <td><?php echo e($amb->alamat); ?></td>
            <td>
              <a href='/siswa/<?php echo e($amb->id); ?>/edit' class="btn btn-sm btn-warning">edit</a>
              <a href='/siswa/<?php echo e($amb->id); ?>/delete' onclick="return confirm('apakah yakin')" class="btn btn-sm btn-danger">delete</a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
      </div>
    </div>  
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/belajar/laravel/belajar_laravel/resources/views/siswa/index.blade.php ENDPATH**/ ?>