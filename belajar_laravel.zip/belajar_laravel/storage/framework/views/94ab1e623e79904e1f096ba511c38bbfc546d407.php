<?php $__env->startSection('content'); ?>
Dashboard
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/belajar/laravel/belajar_laravel/resources/views/dashboard/index.blade.php ENDPATH**/ ?>