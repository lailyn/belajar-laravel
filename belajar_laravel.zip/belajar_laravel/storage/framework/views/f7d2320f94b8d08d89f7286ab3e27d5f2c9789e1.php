<?php $__env->startSection('content'); ?>
    <h1>Edit Data Siswa
    <a href="/siswa" class="btn btn-primary float-right btn-sm">
      Kembali
    </a>
    </h1>    
    <form action="/siswa/<?php echo e($siswa->id); ?>/update" method="POST" enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

      <div class="modal-body">            
        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Nama Depan</label>
          <input type="text" value="<?php echo e($siswa->nama_depan); ?>" name="nama_depan" class="form-control" id="exampleFormControlInput1" placeholder="Nama Depan">
        </div>
        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Nama Belakang</label>
          <input type="text" value="<?php echo e($siswa->nama_belakang); ?>" name="nama_belakang" class="form-control" id="exampleFormControlInput1" placeholder="Nama Belakang">
        </div>
        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Email</label>
          <input type="email" value="<?php echo e($siswa->email); ?>" name="email" class="form-control" id="exampleFormControlInput1" placeholder="Email">
        </div>
        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Jenis Kelamin</label>
          <select name="jenis_kelamin" class="form-control">
            <option <?php if($siswa->jenis_kelamin=='P'): ?> selected <?php endif; ?>>P</option>
            <option <?php if($siswa->jenis_kelamin=='L'): ?> selected <?php endif; ?>>L</option>
          </select>
        </div>
        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Agama</label>
          <select name="agama" class="form-control">
            <option <?php if($siswa->agama=='Islam'): ?> selected <?php endif; ?>>Islam</option>
            <option <?php if($siswa->agama=='Non-Islam'): ?> selected <?php endif; ?>>Non-Islam</option>
          </select>
        </div>
        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Alamat</label>
          <textarea class="form-control" name="alamat" id="exampleFormControlTextarea1" rows="3">
          <?php echo e($siswa->alamat); ?>

          </textarea>
        </div>
        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Avatar</label>
          <input type="file" name="avatar" class="form-control-file">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-warning">Update</button>
      </div>
    </form>        
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/belajar/laravel/belajar_laravel/resources/views/siswa/edit.blade.php ENDPATH**/ ?>