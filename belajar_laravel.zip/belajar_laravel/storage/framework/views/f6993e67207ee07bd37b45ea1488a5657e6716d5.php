
<form action="/hitung/data" method="GET">
Nama: <input type="text" value="<?php echo e($nama); ?>" name="nama"> <br>
Pemakaian: <input type="number" value="<?php echo e($jumlah); ?>" name="jumlah"> <br>
<button type="submit">Hitung</button> <br>
Hasil: <input type="number" value="<?php echo e($hasil); ?>" name="hasil">
</form>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/belajar/laravel/belajar_laravel/resources/views/hitung.blade.php ENDPATH**/ ?>