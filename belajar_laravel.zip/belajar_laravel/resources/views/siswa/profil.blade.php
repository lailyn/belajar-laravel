@extends('layouts.master')
@section('content')
    <h1>Profil Siswa
    <a href="/siswa" class="btn btn-primary float-right btn-sm">
      Kembali
    </a>
    </h1>    
    <div class="media">
      @if(!is_null($siswa->avatar))
      <img class="mr-3" src="{{asset('images/'.$siswa->avatar)}}">      
      @else
      <img width="200px" class="mr-3" src="{{asset('images/default.jpg')}}">      
      @endif  
      
      <div class="media-body">
        Nama Depan : {{$siswa->nama_depan}}<br>
        Nama Belakang : {{$siswa->nama_belakang}}<br>
        Alamat : {{$siswa->alamat}}<br>
        Agama : {{$siswa->agama}}<br>
        Jenis Kelamin : {{$siswa->jenis_kelamin}}<br>
      </div>
      <a href='/siswa/{{$siswa->id}}/edit' class="btn btn-sm btn-warning">edit</a>
    </div>      
@endsection