@extends('layouts.master')
@section('content')
    <h1>Edit Data Siswa
    <a href="/siswa" class="btn btn-primary float-right btn-sm">
      Kembali
    </a>
    </h1>    
    <form action="/siswa/{{$siswa->id}}/update" method="POST" enctype="multipart/form-data">
      {{csrf_field()}}
      <div class="modal-body">            
        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Nama Depan</label>
          <input type="text" value="{{$siswa->nama_depan}}" name="nama_depan" class="form-control" id="exampleFormControlInput1" placeholder="Nama Depan">
        </div>
        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Nama Belakang</label>
          <input type="text" value="{{$siswa->nama_belakang}}" name="nama_belakang" class="form-control" id="exampleFormControlInput1" placeholder="Nama Belakang">
        </div>
        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Email</label>
          <input type="email" value="{{$siswa->email}}" name="email" class="form-control" id="exampleFormControlInput1" placeholder="Email">
        </div>
        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Jenis Kelamin</label>
          <select name="jenis_kelamin" class="form-control">
            <option @if($siswa->jenis_kelamin=='P') selected @endif>P</option>
            <option @if($siswa->jenis_kelamin=='L') selected @endif>L</option>
          </select>
        </div>
        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Agama</label>
          <select name="agama" class="form-control">
            <option @if($siswa->agama=='Islam') selected @endif>Islam</option>
            <option @if($siswa->agama=='Non-Islam') selected @endif>Non-Islam</option>
          </select>
        </div>
        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Alamat</label>
          <textarea class="form-control" name="alamat" id="exampleFormControlTextarea1" rows="3">
          {{$siswa->alamat}}
          </textarea>
        </div>
        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Avatar</label>
          <input type="file" name="avatar" class="form-control-file">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-warning">Update</button>
      </div>
    </form>        
  @endsection