@extends('layouts.master')
@section('content')
    <h1>Add Data Siswa
    <a href="/siswa" class="btn btn-primary float-right btn-sm">
      Kembali
    </a>
    </h1>    
    <form action="/siswa/create" method="POST" enctype="multipart/form-data">
      {{csrf_field()}}
      <div class="modal-body">            
        <div class="mb-3">          
          <label for="exampleFormControlInput1" class="form-label">Nama Depan</label>
          <input type="text" name="nama_depan" class="form-control" id="exampleFormControlInput1" placeholder="Nama Depan">
        </div>
        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Nama Belakang</label>
          <input type="text" name="nama_belakang" class="form-control" id="exampleFormControlInput1" placeholder="Nama Belakang">
        </div>
        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Email</label>
          <input type="email" name="email" class="form-control" id="exampleFormControlInput1" placeholder="Email">
        </div>
        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Jenis Kelamin</label>
          <select name="jenis_kelamin" class="form-control">
            <option>P</option>
            <option>L</option>
          </select>
        </div>
        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Agama</label>
          <select name="agama" class="form-control">
            <option>Islam</option>
            <option>Non-Islam</option>
          </select>
        </div>
        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Alamat</label>
          <textarea class="form-control" name="alamat" id="exampleFormControlTextarea1" rows="3">          
          </textarea>
        </div>
        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Avatar</label>
          <input type="file" name="avatar" class="form-control-file">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-warning">Save</button>
      </div>
    </form>        
  @endsection