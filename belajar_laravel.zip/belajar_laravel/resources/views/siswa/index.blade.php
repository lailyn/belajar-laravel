@extends('layouts.master')
@section('content')
    <h1 class="mt-4">Data Siswa<a href="/siswa/add" class="btn btn-primary btn-sm">Add</a></h1> 
      <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Dashboard</li>
      </ol>      
    @if(session('sukses'))
    <div class="alert alert-success" role="alert">{{session('sukses')}}</div>
    @endif
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>Nama Depan</th>
              <th>Nama Belakang</th>
              <th>JK</th>
              <th>Agama</th>
              <th>Alamat</th>
              <th>Aksi</th>
            </tr>
          </thead>
          @foreach($siswa as $amb)
          <tr>
            <td><a href='/siswa/{{$amb->id}}/profil'>{{$amb->nama_depan}}</a></td>
            <td><a href='/siswa/{{$amb->id}}/profil'>{{$amb->nama_belakang}}</a></td>
            <td>{{$amb->jenis_kelamin}}</td>
            <td>{{$amb->agama}}</td>
            <td>{{$amb->alamat}}</td>
            <td>
              <a href='/siswa/{{$amb->id}}/edit' class="btn btn-sm btn-warning">edit</a>
              <a href='/siswa/{{$amb->id}}/delete' onclick="return confirm('apakah yakin')" class="btn btn-sm btn-danger">delete</a>
            </td>
          </tr>
          @endforeach
        </table>
      </div>
    </div>  
  </div>
  @endsection