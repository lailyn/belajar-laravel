
<form action="/hitung/data" method="GET">
Nama: <input type="text" value="{{$nama}}" name="nama"> <br>
Pemakaian: <input type="number" value="{{$jumlah}}" name="jumlah"> <br>
<button type="submit">Hitung</button> <br>
Hasil: <input type="number" value="{{$hasil}}" name="hasil">
</form>
