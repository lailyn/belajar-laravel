<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HitungController extends Controller
{
    public function index(){
      $data['nama'] = "";
      $data['jumlah'] = "";
      $data['hasil'] = "";
      return view("hitung",$data);
    }
    public function hitung(Request $request){
        $data['nama'] = $request->input('nama');
        $data['jumlah'] = $jumlah = $request->input('jumlah');
        if($jumlah <= 30){
          $hasil = $jumlah * 150;
        }elseif($jumlah <= 60){
          $hasil = (($jumlah-30) * 170) + (30 * 150);
        }elseif($jumlah <= 90){
          $hasil = (($jumlah-60) * 210) + (30 * 150) + (30 * 170);
        }elseif($jumlah <= 120){
          $hasil = (($jumlah-90) * 250) + (30 * 210) + (30 * 150) + (30 * 150);
        }		
        $data['hasil'] = $hasil;
        return view("hitung",$data);
    }
}
