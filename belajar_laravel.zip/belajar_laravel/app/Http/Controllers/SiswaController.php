<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Siswa;

class SiswaController extends Controller
{
    public function index(Request $request){
        if($request->has('cari')) $data['siswa'] = Siswa::where('nama_depan','LIKE','%'.$request->cari.'%')->get();
            else $data['siswa'] = Siswa::all();        
        return view('siswa.index',$data);
    }
    public function create(Request $request){
        Siswa::create($request->all());
        if($request->hasFile('avatar')){
            $request->file('avatar')->move('images/',$request->file('avatar')->getClientOriginalName());
            $siswa->avatar = $request->file('avatar')->getClientOriginalName();
            $siswa->save();
        }
        return redirect('/siswa')->with('sukses','Berhasil Simpan');        
    }
    public function profil($id){
        $data['siswa'] = Siswa::find($id);
        return view('siswa.profil',$data);
    }
    public function edit($id){
        $data['siswa'] = Siswa::find($id);
        return view('siswa.edit',$data);
    }
    public function add(){        
        return view('siswa.add');
    }
    public function update(Request $request,$id){
        $siswa = Siswa::find($id);
        $siswa->update($request->all());
        if($request->hasFile('avatar')){
            $request->file('avatar')->move('images/',$request->file('avatar')->getClientOriginalName());
            $siswa->avatar = $request->file('avatar')->getClientOriginalName();
            $siswa->save();
        }
        return redirect('/siswa')->with('sukses','Berhasil Ubah');        
    }
    public function delete($id){
        $siswa = Siswa::find($id);
        $siswa->delete();
        return redirect('/siswa')->with('sukses','Berhasil Dihapus');        
    }
}
